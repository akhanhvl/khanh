document.querySelector("#earth-open-btn").addEventListener("click", function() {
    document.querySelector("#earth-popup").classList.add("active");
});

document.querySelector("#jupiter-open-btn").addEventListener("click", function() {
    document.querySelector("#jupiter-popup").classList.add("active");
});
document.querySelector("#mars-open-btn").addEventListener("click", function() {
    document.querySelector("#mars-popup").classList.add("active");
});
document.querySelector("#mercucy-open-btn").addEventListener("click", function() {
    document.querySelector("#mercucy-popup").classList.add("active");
});
document.querySelector("#moon-open-btn").addEventListener("click", function() {
    document.querySelector("#moon-popup").classList.add("active");
});
document.querySelector("#neptune-open-btn").addEventListener("click", function() {
    document.querySelector("#neptune-popup").classList.add("active");
});
document.querySelector("#saturn-open-btn").addEventListener("click", function() {
    document.querySelector("#saturn-popup").classList.add("active");
});
document.querySelector("#sun-open-btn").addEventListener("click", function() {
    document.querySelector("#sun-popup").classList.add("active");
});
document.querySelector("#uranus-open-btn").addEventListener("click", function() {
    document.querySelector("#uranus-popup").classList.add("active");
});
document.querySelector("#venus-open-btn").addEventListener("click", function() {
    document.querySelector("#venus-popup").classList.add("active");
});

document.querySelectorAll(".popup .popup-close-btn").forEach(function(closeBtn) {
    closeBtn.addEventListener("click", function() {
        closeBtn.closest(".popup").classList.remove("active");
    });
});